import React from 'react';
import { motion } from 'framer-motion';
import { Icon } from '../components/Icon';

export const Support: React.FC = () => {
    return (
        <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            className="pt-24 px-6 min-h-screen bg-background-dark"
        >
            <div className="max-w-4xl mx-auto">
                <h1 className="font-serif text-4xl text-white mb-12 text-center">Contact Support</h1>
                
                <div className="grid md:grid-cols-2 gap-8 mb-12">
                    <div className="bg-surface-dark-2 p-8 rounded-2xl border border-white/5">
                        <h3 className="text-primary font-bold uppercase tracking-wider text-xs mb-4">Visit Us</h3>
                        <p className="text-white text-lg leading-relaxed mb-6">
                            C Shape Building, Municipal,<br />
                            Near Old Bus Stand,<br />
                            Kunnamkulam, Kerala 680503
                        </p>
                        <h3 className="text-primary font-bold uppercase tracking-wider text-xs mb-4">Call Us</h3>
                        <a href="tel:08547636465" className="text-white text-2xl font-serif hover:text-primary transition-colors block mb-2">
                            085476 36465
                        </a>
                        <p className="text-gray-500 text-sm">Mon - Sat: 9:00 AM - 6:00 PM</p>
                    </div>

                    <div className="h-full min-h-[300px] rounded-2xl overflow-hidden border border-white/10">
                        <iframe 
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3924.580297378776!2d76.07164731479836!3d10.65063999240836!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba7954e76c11b15%3A0x1d473489370776!2sKunnamkulam%2C%20Kerala!5e0!3m2!1sen!2sin!4v1645523456789!5m2!1sen!2sin" 
                            width="100%" 
                            height="100%" 
                            style={{ border: 0 }} 
                            allowFullScreen 
                            loading="lazy"
                        ></iframe>
                    </div>
                </div>

                <div className="fixed bottom-6 right-6 md:hidden">
                    <a 
                        href="tel:08547636465" 
                        className="flex items-center gap-2 bg-primary text-black font-bold px-6 py-4 rounded-full shadow-2xl animate-bounce"
                    >
                        <Icon name="call" /> CALL NOW
                    </a>
                </div>
            </div>
        </motion.div>
    );
};