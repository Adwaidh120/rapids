import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Page, Lead } from '../types';
import { Icon } from '../components/Icon';

interface LeadFormProps {
    onNavigate: (page: Page) => void;
}

export const LeadForm: React.FC<LeadFormProps> = ({ onNavigate }) => {
    const [step, setStep] = useState<'input' | 'otp' | 'success'>('input');
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [otp, setOtp] = useState('');
    const [error, setError] = useState('');

    const handleSendOTP = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || phone.length < 10) {
            setError('Please enter valid details.');
            return;
        }
        setError('');
        setStep('otp');
    };

    const handleVerify = (e: React.FormEvent) => {
        e.preventDefault();
        if (otp.length !== 4) { 
            setError('Invalid OTP');
            return;
        }
        setStep('success');
    };

    return (
        <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            className="min-h-screen flex items-center justify-center bg-background-dark relative overflow-hidden font-sans pt-20"
        >
            <div className="absolute inset-0 z-0 opacity-40 pointer-events-none geo-bg"></div>
            <div className="absolute inset-0 z-0 flex items-center justify-center pointer-events-none">
                <div className="w-[400px] h-[400px] bg-primary/5 rounded-full blur-[150px] animate-pulse-gold"></div>
            </div>

            <main className="relative z-10 w-full max-w-md px-6 py-8">
                <div className="w-full bg-surface-dark/80 glass-card border border-white/10 rounded-3xl p-10 flex flex-col items-center">
                    
                    {step !== 'success' && (
                        <div className="mb-8 text-center">
                            <h1 className="font-serif text-5xl font-bold tracking-widest text-platinum drop-shadow-xl mb-3">
                                RAPIDS
                            </h1>
                            <p className="text-[10px] tracking-[0.4em] text-gray-400 font-medium uppercase">
                                Executive Access
                            </p>
                        </div>
                    )}

                    {step === 'input' && (
                        <form className="w-full mt-4 space-y-6" onSubmit={handleSendOTP}>
                            <div className="group">
                                <label className="block text-[10px] font-bold text-gray-400 mb-2 ml-1 uppercase tracking-widest" htmlFor="fullname">Full Name</label>
                                <div className="relative">
                                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                         <span className="material-symbols-outlined text-gray-500 text-[20px]">person</span>
                                    </div>
                                    <input 
                                        className="block w-full pl-12 pr-4 py-4 bg-black/40 border border-white/10 rounded-lg text-gray-100 placeholder-gray-600 focus:outline-none focus:border-primary/50 focus:bg-black/60 transition-all duration-300 text-sm" 
                                        id="fullname" 
                                        placeholder="e.g., Sarah Jenkins" 
                                        type="text"
                                        value={name}
                                        onChange={(e) => setName(e.target.value)}
                                    />
                                </div>
                            </div>
                            <div className="group">
                                <label className="block text-[10px] font-bold text-gray-400 mb-2 ml-1 uppercase tracking-widest" htmlFor="phone">Phone Number</label>
                                <div className="relative flex">
                                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none z-10">
                                         <img src="https://flagcdn.com/w20/in.png" srcSet="https://flagcdn.com/w40/in.png 2x" width="20" alt="India" className="rounded-sm opacity-80" />
                                         <span className="text-gray-400 text-xs ml-3">+91</span>
                                    </div>
                                    <input 
                                        className="block w-full pl-24 pr-4 py-4 bg-black/40 border border-white/10 rounded-lg text-gray-100 placeholder-gray-600 focus:outline-none focus:border-primary/50 focus:bg-black/60 transition-all duration-300 text-sm" 
                                        id="phone" 
                                        placeholder="98765 43210" 
                                        type="tel"
                                        value={phone}
                                        onChange={(e) => setPhone(e.target.value)}
                                    />
                                </div>
                            </div>
                            
                            {error && <p className="text-red-500 text-xs text-center tracking-wide">{error}</p>}

                            <button className="w-full relative group mt-8 overflow-hidden rounded-lg shadow-[0_10px_40px_-10px_rgba(212,175,55,0.3)]" type="submit">
                                <div className="absolute inset-0 bg-gold-platinum opacity-100 transition-opacity duration-300"></div>
                                <div className="absolute inset-0 bg-white/30 translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out transform skew-y-12"></div>
                                <span className="relative block py-4 px-4 font-serif font-bold text-black tracking-[0.2em] text-sm uppercase">
                                    Request Access
                                </span>
                            </button>
                        </form>
                    )}

                    {step === 'otp' && (
                         <form className="w-full mt-4 space-y-6" onSubmit={handleVerify}>
                             <button type="button" onClick={() => setStep('input')} className="text-xs text-gray-500 hover:text-primary mb-4 flex items-center gap-2 uppercase tracking-wider">
                                <span className="material-symbols-outlined text-[14px]">arrow_back</span> Go Back
                             </button>
                            <div className="group text-center">
                                <label className="block text-[10px] font-bold text-gray-400 mb-4 uppercase tracking-widest" htmlFor="otp">Enter Verification Code</label>
                                <div className="relative">
                                    <input 
                                        className="block w-full py-4 bg-black/40 border border-white/10 rounded-lg text-gray-100 placeholder-gray-700 focus:outline-none focus:border-primary/50 focus:bg-black/60 transition-all duration-300 text-2xl tracking-[0.8em] text-center font-serif" 
                                        id="otp" 
                                        placeholder="0000" 
                                        type="number"
                                        maxLength={4}
                                        value={otp}
                                        onChange={(e) => setOtp(e.target.value)}
                                    />
                                </div>
                                <p className="text-[10px] text-gray-500 mt-3">Sent to +91 {phone}</p>
                            </div>

                            {error && <p className="text-red-500 text-xs text-center">{error}</p>}

                            <button className="w-full relative group mt-8 overflow-hidden rounded-lg shadow-[0_10px_40px_-10px_rgba(212,175,55,0.3)]" type="submit">
                                <div className="absolute inset-0 bg-gold-platinum opacity-100"></div>
                                <span className="relative block py-4 px-4 font-serif font-bold text-black tracking-[0.2em] text-sm uppercase">
                                    Verify Identity
                                </span>
                            </button>
                         </form>
                    )}

                    {step === 'success' && (
                        <div className="w-full mt-8 text-center space-y-8">
                            <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto border border-primary/30 animate-pulse-gold">
                                <span className="material-symbols-outlined text-primary text-5xl">check_circle</span>
                            </div>
                            <div>
                                <h2 className="text-3xl font-serif text-white mb-3">Welcome Aboard</h2>
                                <p className="text-gray-400 text-sm">Initiating secure payment gateway...</p>
                            </div>
                            <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                                <div className="h-full bg-primary w-1/2 animate-shine"></div>
                            </div>
                        </div>
                    )}

                    {step !== 'success' && (
                        <div className="mt-10 text-center space-y-4 w-full">
                            <div className="relative flex items-center justify-center">
                                <div className="border-t border-white/10 w-full absolute"></div>
                                <span className="bg-[#121212] px-4 text-[9px] text-gray-500 uppercase tracking-widest relative z-10">Members Only</span>
                            </div>
                            
                            <p className="text-xs text-gray-500 mt-6">
                                Existing member? 
                                <button className="font-bold text-primary hover:text-white transition-colors ml-1 uppercase tracking-wide" onClick={() => onNavigate('home')}>Log In</button>
                            </p>
                        </div>
                    )}
                </div>
            </main>
        </motion.div>
    );
};