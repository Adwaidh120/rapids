import React, { useState, useEffect } from 'react';
import { Icon } from './Icon';
import { Page } from '../types';

interface NavbarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPage, onNavigate }) => {
  const [scrolled, setScrolled] = useState(false);
  const [isDark, setIsDark] = useState(true);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleTheme = () => {
    const newTheme = !isDark;
    setIsDark(newTheme);
    if (newTheme) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const navLinks: { page: Page; label: string }[] = [
    { page: 'home', label: 'Home' },
    { page: 'courses', label: 'Courses' },
    { page: 'support', label: 'Support' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b ${scrolled ? 'dark:bg-black/90 bg-white/90 backdrop-blur-xl dark:border-white/10 border-black/5 py-4' : 'bg-transparent border-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        
        {/* Logo */}
        <button onClick={() => onNavigate('home')} className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-primary-dark flex items-center justify-center shadow-[0_0_15px_rgba(212,175,55,0.3)] group-hover:shadow-[0_0_25px_rgba(212,175,55,0.5)] transition-shadow">
             <Icon name="diamond" className="text-black" />
          </div>
          <span className="font-serif text-xl font-bold tracking-[0.2em] dark:text-white text-black group-hover:text-primary transition-colors">RAPIDS</span>
        </button>

        {/* Desktop Nav */}
        <div className="flex items-center gap-6">
            <div className="hidden md:flex items-center gap-8 bg-white/5 dark:bg-white/5 bg-black/5 px-6 py-2 rounded-full border dark:border-white/5 border-black/5 backdrop-blur-sm">
            {navLinks.map((link) => (
                <button
                key={link.page}
                onClick={() => onNavigate(link.page)}
                className={`text-sm font-medium tracking-wide transition-all duration-300 relative px-4 py-1 font-serif ${
                    currentPage === link.page || (currentPage === 'landing-communication' && link.page === 'courses') 
                    ? 'text-primary' : 'dark:text-gray-400 text-gray-600 hover:text-black dark:hover:text-white'
                }`}
                >
                {link.label}
                {(currentPage === link.page || (currentPage === 'landing-communication' && link.page === 'courses')) && (
                    <span className="absolute -bottom-1 left-2 right-2 h-0.5 bg-primary shadow-[0_0_8px_#D4AF37] rounded-full"></span>
                )}
                </button>
            ))}
            </div>

            {/* Theme Toggle - Visible only on Home page top right */}
            {currentPage === 'home' && (
                <button 
                    onClick={toggleTheme}
                    className="w-10 h-10 rounded-full bg-black/5 dark:bg-white/10 flex items-center justify-center text-gray-600 dark:text-yellow-400 hover:scale-110 transition-transform"
                    title="Toggle Theme"
                >
                    <Icon name={isDark ? "light_mode" : "dark_mode"} size="sm" />
                </button>
            )}

             {/* Mobile Menu Icon */}
            <button onClick={() => onNavigate('support')} className="md:hidden text-primary">
                <Icon name="menu" />
            </button>
        </div>
      </div>
    </nav>
  );
};