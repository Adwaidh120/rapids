import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import { Page } from './types';
import { Navbar } from './components/Navigation';
import { Home } from './pages/Home';
import { Courses } from './pages/Courses';
import { LandingCommunication } from './pages/LandingCommunication';
import { LeadForm } from './pages/LeadForm';
import { Support } from './pages/Support';
import { Policy } from './pages/Policy';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');

  const navigateTo = (page: Page) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setCurrentPage(page);
  };

  // Prevent scroll restoration issues
  useEffect(() => {
    window.scrollTo(0,0);
  }, [currentPage]);

  return (
    <div className="bg-background-dark min-h-screen text-gray-200 font-sans antialiased selection:bg-primary selection:text-black flex flex-col">
      
      <Navbar 
        currentPage={currentPage}
        onNavigate={navigateTo}
      />

      <main className="flex-1 relative z-10">
        <AnimatePresence mode='wait'>
          {currentPage === 'home' && <Home key="home" onNavigate={navigateTo} />}
          {currentPage === 'courses' && <Courses key="courses" onNavigate={navigateTo} />}
          {currentPage === 'landing-communication' && <LandingCommunication key="landing" onNavigate={navigateTo} />}
          {currentPage === 'lead-form' && <LeadForm key="lead" onNavigate={navigateTo} />}
          {currentPage === 'support' && <Support key="support" />}
          {currentPage === 'policy' && <Policy key="policy" />}
        </AnimatePresence>
      </main>

      {/* Website Footer */}
      <footer className="bg-black border-t border-white/10 py-12 px-6 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
             <span className="material-icons-round text-primary">diamond</span>
             <span className="font-serif text-lg font-bold tracking-[0.2em] text-white">RAPIDS</span>
          </div>
          <div className="flex gap-8 text-sm text-gray-500">
            <button onClick={() => navigateTo('policy')} className="hover:text-primary transition-colors">Privacy Policy</button>
            <button onClick={() => navigateTo('policy')} className="hover:text-primary transition-colors">Terms of Service</button>
            <button onClick={() => navigateTo('support')} className="hover:text-primary transition-colors">Support</button>
          </div>
          <div className="text-xs text-gray-600">
            © 2024 Rapids Training. All rights reserved.
          </div>
        </div>
      </footer>
      
    </div>
  );
}