export type Page = 'home' | 'courses' | 'landing-communication' | 'lead-form' | 'support' | 'policy';

export interface Course {
  id: string;
  title: string;
  subtitle: string;
  image: string;
  status?: 'active' | 'coming_soon';
  bookingFee?: number;
  totalFee?: number;
  isLocked?: boolean;
  rating?: number;
  isPopular?: boolean;
  category?: string;
  students?: number;
  progress?: number;
}

export interface Lead {
  fullName: string;
  phoneNumber: string;
  isVerified: boolean;
  submittedAt: string; // ISO Date string
}

export interface User {
  name: string;
  avatar: string;
}